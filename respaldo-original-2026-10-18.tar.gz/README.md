# Café Doña Tere · tienda de origen

Aplicación de comercio electrónico en **Next.js App Router, React y TypeScript**, diseñada para crecer desde la tienda pública hasta la operación diaria del comercio. La base de datos es PostgreSQL en Supabase; el checkout colombiano usa Wompi Web Checkout. El frontend usa Server Components para catálogo y páginas, y componentes de cliente solo para interacciones de tienda.

## Desarrollo local

Requisitos: Node.js 20.9 o posterior y npm.

```bash
npm install
cp .env.example .env.local
npm run dev
```

Abre `http://localhost:4173`. Sin credenciales aparecen los cafés y precios de referencia para explorar la experiencia. **El checkout permanece deshabilitado y no crea pedidos ni simula pagos** hasta configurar el servidor.

Comandos de aplicación:

```bash
npm run dev
npm run typecheck
npm run build
npm start
```

## Arquitectura de la tienda

- Catálogo público filtrable, variantes de peso, molienda, perfil de taza y carrito persistente en el navegador.
- El precio, el inventario, el total y la tarifa de envío se vuelven a consultar y calcular en servidor al iniciar un pedido. No se aceptan valores monetarios del navegador.
- Una función transaccional en PostgreSQL bloquea la variante, reserva unidades, calcula el total y crea los renglones del pedido.
- Wompi Web Checkout recibe una referencia única, COP, firma SHA-256 de integridad y vencimiento de 30 minutos. El secreto se conserva en servidor.
- El endpoint `/api/webhooks/wompi` valida la firma, exige que ID/estado/monto estén cubiertos y consulta la transacción con la llave privada para confirmar también referencia, moneda y estado antes de conciliar el pago.
- Cada pedido tiene un enlace de seguimiento aleatorio. Solo se almacena el hash del token; el enlace no expone la dirección, correo ni teléfono del comprador.
- `/admin` verifica una sesión Supabase y el rol `admin` en `app_metadata`. Incluye ventas de los últimos siete días, pedidos, niveles bajos de stock, actualización de inventario, presentaciones y precios, y avances de preparación/despacho.
- Las tablas privadas tienen RLS; secretos de Supabase/Wompi solo se usan en servidor. Se añaden cabeceras de seguridad, validación de esquema, validación de origen y límite de solicitudes de checkout en base de datos.

## Conectar Supabase

1. Crea un proyecto de Supabase y copia la URL, la llave publicable y la llave secreta de servicio a `.env.local` (`NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`). La llave de servicio nunca debe llevar el prefijo `NEXT_PUBLIC_` ni llegar al navegador.
2. Aplica `supabase/migrations/202610180001_store_core.sql` desde el editor SQL de Supabase.
3. Crea una cuenta de Auth para cada persona administradora y asigna `app_metadata.role = 'admin'` desde un entorno de confianza. No asignes ese rol en `user_metadata`, que el usuario puede editar.
4. Aplica también `supabase/migrations/202610180002_hardening_and_operations.sql`. Esta migración limita la información de inventario expuesta al catálogo público, registra el consentimiento de privacidad, añade la cola de conciliación de pagos y endurece los cambios de estado. Ambas migraciones son necesarias para la versión actual de la aplicación.
5. En el panel `/admin`, confirma el nombre/peso/precio de cada presentación, registra sus unidades disponibles y configura tarifas aprobadas por ciudad. El catálogo de referencia inicia con precios sin confirmar y stock cero, y no existen tarifas de entrega hasta que el comercio las cree.

Ejemplo para asignar el rol desde el editor SQL de Supabase, reemplazando el correo por el de la cuenta administradora:

```sql
update auth.users
set raw_app_meta_data = coalesce(raw_app_meta_data, '{}'::jsonb) || '{"role":"admin"}'::jsonb
where email = 'admin@example.com';
```

Configura políticas de acceso de Auth para el dominio real de la tienda antes de publicar.

## Conectar Wompi

1. En `.env.local`, define `WOMPI_ENVIRONMENT=test`, las llaves pública `pub_test_…` y privada `prv_test_…`, el secreto de integridad y el secreto de eventos del ambiente de pruebas. La llave privada solo se usa en servidor para cotejar cada evento con la API de Wompi. Para producción cambia de forma coordinada a `WOMPI_ENVIRONMENT=production` y a las llaves `pub_prod_…` / `prv_prod_…`; usa HTTPS en el dominio público.
2. Define `NEXT_PUBLIC_SITE_URL` con el origen HTTPS exacto de la tienda. En `/admin`, configura la tarifa de domicilio aprobada para cada municipio servido; la ciudad digitada se normaliza y su tarifa se agrega al pedido en servidor. No se debe activar checkout hasta cargar las tarifas y zonas reales.
3. Registra en el Dashboard de Wompi el webhook `https://tu-dominio/api/webhooks/wompi` para el evento `transaction.updated`.
4. Prueba pagos, rechazos, expiraciones y eventos repetidos en sandbox. Wompi devuelve al cliente a la página de seguimiento, pero solo el webhook autenticado marca un pago como aprobado.
5. Activa una tarea programada confiable cada cinco minutos para ejecutar `select public.expire_checkout_orders();`. La función admite al rol de base de datos de un job interno y rechaza los roles de API públicos. El checkout también libera reservas vencidas cuando entra un pedido nuevo; el cron evita mantener stock bloqueado si la tienda no recibe más pedidos.
6. Programa una limpieza diaria con `select public.prune_store_rate_limits();` para borrar huellas temporales de limitación de solicitudes.
7. Después de confirmar precios, stock, tarifas, textos legales y credenciales de producción, define `STORE_CHECKOUT_ENABLED=true`, una versión no borrador en `PRIVACY_POLICY_VERSION` (por ejemplo, `2026-10-v1`) y el origen HTTPS exacto en `NEXT_PUBLIC_SITE_URL`. La app mantiene el checkout apagado mientras falte cualquiera de estas condiciones. Edita `/privacidad` con la identidad real del responsable antes de habilitarlo.

`RATE_LIMIT_SECRET` es opcional, pero en producción conviene configurarlo con un secreto aleatorio propio de al menos 32 bytes, distinto de las credenciales de Wompi y Supabase. El rate limit del acceso administrativo limita tanto por dirección del cliente como por huella derivada del correo. Configura el proxy de publicación para que `X-Forwarded-For` incluya la dirección del cliente en su último elemento; no expongas la app detrás de un proxy que conserve valores enviados libremente por el navegador.

Los pedidos con un pago tardío aprobado y sin inventario suficiente quedan en `PAYMENT_REVIEW` para resolverlos con el cliente antes del despacho. Los pagos duplicados generan una alerta en el panel; verifica y gestiona allí el reembolso correspondiente en Wompi.

El checkout usa el formulario alojado por Wompi. Para Colombia, los métodos disponibles dependen de la configuración y elegibilidad de la cuenta del comercio. Revisa la [guía oficial de Widget y Web Checkout](https://docs.wompi.co/docs/colombia/widget-checkout-web/), la [guía oficial de eventos y firma](https://docs.wompi.co/docs/colombia/eventos/) y la [guía de métodos de pago](https://docs.wompi.co/docs/colombia/metodos-de-pago/).

## Información comercial que debe confirmarse

Los materiales entregados no coinciden en algunos precios, pesos y disponibilidad. El catálogo mantiene esos datos como referencias y la migración comienza con `price_confirmed = false` y `stock_on_hand = 0`; no se cobra hasta que el administrador los actualice. El café de leña de 500 g aparece con precios distintos en los archivos, la etiqueta Honey no coincide con el peso anunciado, la presentación de 250 g no tiene precio y la tostión de precisión no tiene precio confirmado. Las tarifas de domicilio por municipio, los tiempos, las zonas, los cambios/devoluciones, los datos del responsable de comercio y la política definitiva de tratamiento de datos también deben completarse antes de la salida pública.

`/privacidad` es un **borrador de configuración**, no un texto jurídico final. Completa la identidad y canales reales del responsable y haz revisar las condiciones comerciales y el aviso de privacidad para el comercio.

## Referencias del proyecto

- El prototipo estático anterior se conserva en `legacy-prototype/` para consulta. Los recursos gráficos se publican desde `public/assets/`.
- Los datos originales de marca y café proceden de documentos e imágenes locales. Lavado, Natural y la caja de degustación eran ideas de temporada y no se ofrecen como productos confirmados.
- El diseño explora una dirección editorial más cálida, con fotografía de finca, guía de sabor, presentaciones variables, carrito lateral accesible, estados de pedido, panel de administración adaptable y estilos de movimiento reducido.
