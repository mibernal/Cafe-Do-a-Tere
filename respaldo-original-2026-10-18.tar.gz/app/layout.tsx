import type { Metadata } from "next";
import { DM_Sans, Playfair_Display } from "next/font/google";
import "./globals.css";

const sans = DM_Sans({ subsets: ["latin"], variable: "--font-sans", display: "swap" });
const serif = Playfair_Display({ subsets: ["latin"], variable: "--font-serif", display: "swap" });

function metadataBase() {
  try {
    return process.env.NEXT_PUBLIC_SITE_URL ? new URL(process.env.NEXT_PUBLIC_SITE_URL) : undefined;
  } catch {
    return undefined;
  }
}

export const metadata: Metadata = {
  metadataBase: metadataBase(),
  title: { default: "Café Doña Tere | Café de origen de Cachipay", template: "%s · Café Doña Tere" },
  description: "Café colombiano de Finca La Libertad, Cachipay. Perfiles tostados con calma, para compartir todos los días.",
  applicationName: "Café Doña Tere",
  openGraph: {
    title: "Café Doña Tere · De nuestra finca a tu mesa",
    description: "Café colombiano de Finca La Libertad, Cachipay.",
    locale: "es_CO",
    type: "website",
    images: ["/assets/roasting.jpg"],
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="es-CO"><body className={`${sans.variable} ${serif.variable}`}>{children}</body></html>;
}
