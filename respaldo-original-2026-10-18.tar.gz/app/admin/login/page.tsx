import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { AdminLoginForm } from "@/components/admin-login-form";

export const metadata: Metadata = {
  title: "Acceso administrativo",
  robots: { index: false, follow: false, noarchive: true },
};
export const dynamic = "force-dynamic";

export default function AdminLoginPage() {
  return (
    <main className="admin-login-page">
      <Link className="brand admin-login-brand" href="/">
        <Image
          src="/assets/logo-cafe-dona-tere.png"
          alt=""
          width={48}
          height={48}
        />
        <span>
          <strong>Café Doña Tere</strong>
          <small>Panel de tienda</small>
        </span>
      </Link>
      <section className="admin-login-card">
        <p className="overline">
          <span />
          ACCESO RESTRINGIDO
        </p>
        <h1>
          Bienvenido
          <br />
          <em>de vuelta.</em>
        </h1>
        <p>
          Ingresa con tu cuenta administradora para gestionar pedidos e
          inventario.
        </p>
        <AdminLoginForm />
      </section>
      <Link className="admin-back-link" href="/">
        ← Volver a la tienda
      </Link>
    </main>
  );
}
