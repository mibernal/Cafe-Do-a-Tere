import type { Metadata } from "next";
import { redirect } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import {
  BarChart3,
  Coffee,
  Package,
  PackageCheck,
  ShieldCheck,
  ShoppingBag,
  Wallet,
} from "lucide-react";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createAdminClient, hasDatabaseConfig } from "@/lib/supabase/admin";
import { formatCOP } from "@/lib/money";
import {
  CatalogTable,
  InventoryTable,
  OrdersTable,
  ShippingRatesTable,
} from "@/components/admin-console";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Centro de operaciones",
  robots: { index: false, follow: false, noarchive: true },
};

export default async function AdminPage() {
  if (!hasDatabaseConfig() || !process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY)
    return (
      <main className="admin-setup">
        <Link className="brand" href="/">
          <Image
            src="/assets/logo-cafe-dona-tere.png"
            alt=""
            width={48}
            height={48}
          />
          <span>
            <strong>Café Doña Tere</strong>
            <small>Panel de tienda</small>
          </span>
        </Link>
        <h1>Panel operativo</h1>
        <p>
          Configura Supabase y aplica la migración de base de datos para activar
          pedidos, métricas e inventario.
        </p>
        <Link className="button button-dark" href="/">
          Volver a la tienda
        </Link>
      </main>
    );
  const auth = await createSupabaseServerClient();
  const {
    data: { user },
  } = await auth.auth.getUser();
  if (!user || user.app_metadata.role !== "admin") redirect("/admin/login");
  const db = createAdminClient();
  const [ordersResult, variantsResult, metricsResult, shippingResult] =
    await Promise.all([
      db
        .from("orders")
        .select(
          "id,reference,status,payment_review_reason,customer_name,customer_phone,customer_email,city,address,delivery_notes,total_cop,created_at,courier_tracking_url",
        )
        .order("created_at", { ascending: false })
        .limit(30),
      db
        .from("product_variants")
        .select(
          "id,label,weight_grams,price_cop,price_confirmed,stock_on_hand,stock_reserved,grinds,products(name)",
        )
        .order("sort_order"),
      db.from("admin_store_metrics").select("*").single(),
      db
        .from("shipping_rates")
        .select("city_key,city_label,price_cop,is_active")
        .order("city_label"),
    ]);
  const orders = ordersResult.data ?? [];
  const variants = (variantsResult.data ?? []).map((row: any) => ({
    id: row.id,
    label: row.label,
    weightGrams: row.weight_grams,
    priceCop: row.price_cop,
    priceConfirmed: row.price_confirmed,
    stockOnHand: row.stock_on_hand,
    stockReserved: row.stock_reserved,
    grinds: row.grinds ?? ["Molido"],
    productName: row.products?.name ?? "Producto",
  }));
  const metrics = metricsResult.data ?? {
    paid_revenue_cop: 0,
    revenue_7d_cop: 0,
    paid_orders: 0,
    pending_orders: 0,
    total_orders: 0,
    low_stock_variants: 0,
    payment_review_orders: 0,
  };
  return (
    <main className="admin-page">
      <header className="admin-header">
        <Link className="brand" href="/">
          <Image
            src="/assets/logo-cafe-dona-tere.png"
            alt=""
            width={44}
            height={44}
          />
          <span>
            <strong>Café Doña Tere</strong>
            <small>Centro de operaciones</small>
          </span>
        </Link>
        <div>
          <span className="admin-user">
            <i />
            {user.email}
          </span>
          <form action="/api/admin/logout" method="post">
            <button className="logout-button">Cerrar sesión</button>
          </form>
        </div>
      </header>
      <div className="admin-main">
        <div className="admin-welcome">
          <div>
            <p className="overline">
              <span />
              RESUMEN DE LA TIENDA
            </p>
            <h1>
              Buenos días,
              <br />
              <em>Doña Tere.</em>
            </h1>
            <p>Una vista clara de lo que sucede hoy con tus cafés.</p>
          </div>
          <span className="admin-date">
            <BarChart3 size={16} /> Operación en tiempo real
          </span>
        </div>
        <section className="metric-grid">
          <article>
            <span>
              <Wallet />
            </span>
            <small>VENTAS · ÚLTIMOS 7 DÍAS</small>
            <strong>{formatCOP(Number(metrics.revenue_7d_cop ?? 0))}</strong>
            <p>
              Histórico {formatCOP(Number(metrics.paid_revenue_cop ?? 0))} ·{" "}
              {metrics.paid_orders ?? 0} pedidos pagados
            </p>
          </article>
          <article>
            <span>
              <ShoppingBag />
            </span>
            <small>PEDIDOS PENDIENTES</small>
            <strong>{metrics.pending_orders ?? 0}</strong>
            <p>Esperando confirmación de pago</p>
          </article>
          <article>
            <span>
              <PackageCheck />
            </span>
            <small>PEDIDOS REGISTRADOS</small>
            <strong>{metrics.total_orders ?? 0}</strong>
            <p>Histórico total de la tienda</p>
          </article>
          <article>
            <span>
              <Package />
            </span>
            <small>REFERENCIAS BAJAS</small>
            <strong>{metrics.low_stock_variants ?? 0}</strong>
            <p>5 unidades o menos disponibles</p>
          </article>
          <article
            className={
              Number(metrics.payment_review_orders ?? 0) > 0
                ? "metric-alert"
                : ""
            }
          >
            <span>
              <ShieldCheck />
            </span>
            <small>PAGOS POR REVISAR</small>
            <strong>{metrics.payment_review_orders ?? 0}</strong>
            <p>Conciliación o doble pago</p>
          </article>
        </section>
        <section className="admin-section">
          <div className="admin-section-head">
            <div>
              <p className="overline">
                <span />
                MOVIMIENTO RECIENTE
              </p>
              <h2>Pedidos</h2>
            </div>
            <span className="admin-count">{orders.length} recientes</span>
          </div>
          {ordersResult.error ? (
            <p className="admin-error">
              No fue posible consultar los pedidos. Revisa las tablas de
              Supabase.
            </p>
          ) : (
            <OrdersTable orders={orders as any[]} />
          )}
        </section>
        <section className="admin-section">
          <div className="admin-section-head">
            <div>
              <p className="overline">
                <span />
                CONTROL DE STOCK
              </p>
              <h2>Inventario</h2>
            </div>
            <span className="admin-count">
              <Coffee size={14} /> {variants.length} presentaciones
            </span>
          </div>
          {variantsResult.error ? (
            <p className="admin-error">
              No fue posible consultar el inventario. Revisa las tablas de
              Supabase.
            </p>
          ) : (
            <InventoryTable variants={variants} />
          )}
        </section>
        <section className="admin-section">
          <div className="admin-section-head">
            <div>
              <p className="overline">
                <span />
                CONFIGURACIÓN DE CATÁLOGO
              </p>
              <h2>Precios y presentaciones</h2>
            </div>
          </div>
          {variantsResult.error ? (
            <p className="admin-error">
              No fue posible consultar las presentaciones.
            </p>
          ) : (
            <CatalogTable variants={variants} />
          )}
        </section>
        <section className="admin-section">
          <div className="admin-section-head">
            <div>
              <p className="overline">
                <span />
                DESTINOS DE ENTREGA
              </p>
              <h2>Tarifas de domicilio</h2>
            </div>
            <span className="admin-count">
              La ciudad determina el costo cobrado
            </span>
          </div>
          {shippingResult.error ? (
            <p className="admin-error">
              No fue posible consultar las tarifas de domicilio.
            </p>
          ) : (
            <ShippingRatesTable rates={shippingResult.data ?? []} />
          )}
        </section>
        <p className="admin-footnote">
          Los cobros se confirman con el webhook firmado de Wompi. El inventario
          reservado y los movimientos quedan auditados en la base de datos.
        </p>
      </div>
    </main>
  );
}
