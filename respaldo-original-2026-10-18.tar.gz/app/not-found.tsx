import Link from "next/link";

export const dynamic = "force-dynamic";

export default function NotFound() {
  return <main className="admin-setup"><p className="overline"><span />CAFÉ DOÑA TERE</p><h1>Esta página<br /><em>no está disponible.</em></h1><p>Revisa el enlace o vuelve a la selección de cafés de Finca La Libertad.</p><Link className="button button-dark" href="/">Volver a la tienda</Link></main>;
}
