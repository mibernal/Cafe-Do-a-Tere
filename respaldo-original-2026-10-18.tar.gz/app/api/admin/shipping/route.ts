import { NextResponse } from "next/server";
import { z } from "zod";
import { readJsonBody, sameOriginRequest } from "@/lib/request";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

const shippingRate = z.object({ cityKey: z.string().regex(/^[a-z0-9-]{2,80}$/).optional(), cityLabel: z.string().trim().min(2).max(80), priceCop: z.number().int().min(0).max(100000000), active: z.boolean() }).strict();

function cityKey(value: string) {
  return value.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 80);
}

export async function PATCH(request: Request) {
  if (!sameOriginRequest(request)) return NextResponse.json({ error: "Solicitud no válida." }, { status: 403 });
  const auth = await createSupabaseServerClient();
  const { data: { user } } = await auth.auth.getUser();
  if (!user || user.app_metadata.role !== "admin") return NextResponse.json({ error: "No autorizado." }, { status: 401 });
  const requestBody = await readJsonBody(request, 8_192);
  if (!requestBody.ok) return NextResponse.json({ error: requestBody.error }, { status: requestBody.status });
  const parsed = shippingRate.safeParse(requestBody.value);
  if (!parsed.success) return NextResponse.json({ error: "Revisa el municipio y el valor del domicilio." }, { status: 400 });
  const key = parsed.data.cityKey ?? cityKey(parsed.data.cityLabel);
  if (key.length < 2) return NextResponse.json({ error: "El municipio debe tener un nombre válido." }, { status: 400 });
  const db = createAdminClient();
  const { data, error } = await db.rpc("admin_configure_shipping_rate", { p_city_key: key, p_city_label: parsed.data.cityLabel, p_price_cop: parsed.data.priceCop, p_active: parsed.data.active, p_admin_id: user.id });
  if (error || data !== true) return NextResponse.json({ error: "No se pudo guardar la tarifa de envío." }, { status: 409 });
  return NextResponse.json({ ok: true });
}
