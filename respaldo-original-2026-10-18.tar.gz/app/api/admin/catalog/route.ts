import { NextResponse } from "next/server";
import { z } from "zod";
import { readJsonBody, sameOriginRequest } from "@/lib/request";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { GRIND_OPTIONS } from "@/lib/grind-options";

const allowedGrinds = new Set<string>(GRIND_OPTIONS.map((option) => option.value));

const variantSchema = z.object({
  variantId: z.string().min(1).max(80),
  label: z.string().trim().min(2).max(60),
  weightGrams: z.number().int().min(50).max(20000),
  priceCop: z.number().int().min(0).max(100000000),
  priceConfirmed: z.boolean(),
  grinds: z.array(z.string().min(1).max(80)).min(1).max(GRIND_OPTIONS.length)
    .refine((values) => values.every((value) => allowedGrinds.has(value)))
    .refine((values) => new Set(values).size === values.length),
}).strict();

export async function PATCH(request: Request) {
  if (!sameOriginRequest(request)) return NextResponse.json({ error: "Solicitud no válida." }, { status: 403 });
  const auth = await createSupabaseServerClient();
  const { data: { user } } = await auth.auth.getUser();
  if (!user || user.app_metadata.role !== "admin") return NextResponse.json({ error: "No autorizado." }, { status: 401 });
  const requestBody = await readJsonBody(request, 8_192);
  if (!requestBody.ok) return NextResponse.json({ error: requestBody.error }, { status: requestBody.status });
  const parsed = variantSchema.safeParse(requestBody.value);
  if (!parsed.success) return NextResponse.json({ error: "Revisa la presentación y el precio." }, { status: 400 });
  const db = createAdminClient();
  const { data, error } = await db.rpc("admin_configure_variant", {
    p_variant_id: parsed.data.variantId, p_label: parsed.data.label, p_weight_grams: parsed.data.weightGrams,
    p_price_cop: parsed.data.priceCop, p_price_confirmed: parsed.data.priceConfirmed,
    p_grinds: parsed.data.grinds, p_admin_id: user.id,
  });
  if (error || data !== true) return NextResponse.json({ error: "No se pudo guardar la presentación." }, { status: 409 });
  return NextResponse.json({ ok: true });
}
