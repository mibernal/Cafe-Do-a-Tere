import { NextResponse } from "next/server";
import { z } from "zod";
import { readJsonBody, sameOriginRequest } from "@/lib/request";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

const orderUpdate = z.object({ orderId: z.uuid(), status: z.enum(["PREPARING", "SHIPPED", "DELIVERED"]), trackingUrl: z.url().max(500).optional().or(z.literal("")) }).strict();

export async function PATCH(request: Request) {
  if (!sameOriginRequest(request)) return NextResponse.json({ error: "Solicitud no válida." }, { status: 403 });
  const auth = await createSupabaseServerClient();
  const { data: { user } } = await auth.auth.getUser();
  if (!user || user.app_metadata.role !== "admin") return NextResponse.json({ error: "No autorizado." }, { status: 401 });
  const requestBody = await readJsonBody(request, 8_192);
  if (!requestBody.ok) return NextResponse.json({ error: requestBody.error }, { status: requestBody.status });
  const parsed = orderUpdate.safeParse(requestBody.value);
  if (!parsed.success) return NextResponse.json({ error: "Revisa el estado del pedido." }, { status: 400 });
  const trackingUrl = parsed.data.trackingUrl ?? "";
  if (trackingUrl && new URL(trackingUrl).protocol !== "https:") return NextResponse.json({ error: "El enlace de seguimiento debe ser seguro (HTTPS)." }, { status: 400 });
  const db = createAdminClient();
  const { data, error } = await db.rpc("admin_update_order", { p_order_id: parsed.data.orderId, p_status: parsed.data.status, p_tracking_url: trackingUrl });
  if (error || data !== true) {
    const message = data === false && parsed.data.status === "PREPARING"
      ? "No hay inventario suficiente para confirmar este pedido. Repón las unidades y vuelve a intentarlo."
      : "No se pudo actualizar el pedido o el cambio de estado no es válido.";
    return NextResponse.json({ error: message }, { status: 409 });
  }
  return NextResponse.json({ ok: true });
}
