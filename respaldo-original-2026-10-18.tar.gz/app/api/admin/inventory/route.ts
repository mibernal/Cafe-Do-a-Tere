import { NextResponse } from "next/server";
import { z } from "zod";
import { readJsonBody, sameOriginRequest } from "@/lib/request";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

const inventoryAdjustment = z.object({ variantId: z.string().min(1).max(80), delta: z.number().int().min(-10000).max(10000).refine((value) => value !== 0), note: z.string().trim().min(2).max(200) }).strict();

export async function POST(request: Request) {
  if (!sameOriginRequest(request)) return NextResponse.json({ error: "Solicitud no válida." }, { status: 403 });
  const auth = await createSupabaseServerClient();
  const { data: { user } } = await auth.auth.getUser();
  if (!user || user.app_metadata.role !== "admin") return NextResponse.json({ error: "No autorizado." }, { status: 401 });
  const requestBody = await readJsonBody(request, 8_192);
  if (!requestBody.ok) return NextResponse.json({ error: requestBody.error }, { status: requestBody.status });
  const parsed = inventoryAdjustment.safeParse(requestBody.value);
  if (!parsed.success) return NextResponse.json({ error: "Revisa los datos de inventario." }, { status: 400 });
  const db = createAdminClient();
  const { data, error } = await db.rpc("admin_adjust_inventory", { p_variant_id: parsed.data.variantId, p_delta: parsed.data.delta, p_note: parsed.data.note, p_admin_id: user.id });
  if (error || data !== true) return NextResponse.json({ error: "No se pudo ajustar el inventario; revisa las unidades reservadas." }, { status: 409 });
  return NextResponse.json({ ok: true });
}
