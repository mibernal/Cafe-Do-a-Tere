import { createHash, randomBytes } from "node:crypto";
import { NextResponse } from "next/server";
import { z } from "zod";
import { createAdminClient } from "@/lib/supabase/admin";
import { isStoreCheckoutEnabled } from "@/lib/store-config";
import { rateLimitFingerprint, readJsonBody, sameOriginRequest } from "@/lib/request";
import { wompiCheckoutConfig } from "@/lib/wompi";

export const runtime = "nodejs";

const checkoutSchema = z.object({
  customer: z.object({
    name: z.string().trim().min(2).max(100),
    email: z.email().max(254),
    phone: z.string().trim().min(7).max(20).regex(/^[0-9 +().-]+$/),
    city: z.string().trim().min(2).max(80),
    address: z.string().trim().min(5).max(180),
    notes: z.string().trim().max(300).optional().default(""),
  }).strict(),
  privacyConsent: z.literal(true),
  items: z.array(z.object({
    variantId: z.string().min(1).max(80),
    grind: z.string().trim().min(1).max(40),
    quantity: z.number().int().min(1).max(10),
  }).strict()).min(1).max(10),
}).strict();

function cityKey(value: string) {
  return value.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 80);
}

export async function POST(request: Request) {
  if (!sameOriginRequest(request)) return NextResponse.json({ error: "Solicitud no válida." }, { status: 403 });
  const requestBody = await readJsonBody(request, 32_768);
  if (!requestBody.ok) return NextResponse.json({ error: requestBody.error }, { status: requestBody.status });
  const parsed = checkoutSchema.safeParse(requestBody.value);
  if (!parsed.success) return NextResponse.json({ error: "Revisa los datos de entrega y los productos seleccionados." }, { status: 400 });

  if (!isStoreCheckoutEnabled()) {
    return NextResponse.json({ error: "La tienda aún está afinando sus precios, entregas y medios de pago. Escríbenos por WhatsApp para confirmar tu pedido." }, { status: 503 });
  }

  const supabase = createAdminClient();
  const originFingerprint = rateLimitFingerprint(request, "checkout");
  const { data: allowed, error: limitError } = await supabase.rpc("consume_checkout_limit", { p_fingerprint: originFingerprint });
  if (limitError || allowed !== true) return NextResponse.json({ error: "No fue posible iniciar otro pedido en este momento. Intenta de nuevo más tarde." }, { status: limitError ? 503 : 429 });

  const reference = `CDT-${Date.now().toString(36).toUpperCase()}-${randomBytes(5).toString("hex").toUpperCase()}`;
  const trackingToken = randomBytes(32).toString("base64url");
  const trackingTokenHash = createHash("sha256").update(trackingToken).digest("hex");
  const { data: order, error } = await supabase.rpc("create_checkout_order", {
    p_reference: reference,
    p_city_key: cityKey(parsed.data.customer.city),
    p_customer: {
      ...parsed.data.customer,
      privacyConsent: parsed.data.privacyConsent,
      privacyPolicyVersion: process.env.PRIVACY_POLICY_VERSION,
    },
    p_items: parsed.data.items,
    p_tracking_token_hash: trackingTokenHash,
  });

  if (error || !order?.total_cop) {
    const shippingMissing = error?.message.includes("shipping rate unavailable");
    return NextResponse.json({ error: shippingMissing ? "Aún no tenemos una tarifa de domicilio configurada para esta ciudad. Escríbenos por WhatsApp y te ayudamos." : "No pudimos reservar los productos. Verifica su disponibilidad o contáctanos para ayudarte." }, { status: 409 });
  }
  try {
    const checkout = wompiCheckoutConfig(reference, Number(order.total_cop), trackingToken);
    return NextResponse.json({ checkout, subtotalCop: Number(order.subtotal_cop), shippingCop: Number(order.shipping_cop), totalCop: Number(order.total_cop) }, { headers: { "Cache-Control": "private, no-store" } });
  } catch {
    await supabase.rpc("cancel_checkout_order", { p_reference: reference, p_reason: "No fue posible preparar el pago." });
    return NextResponse.json({ error: "El medio de pago no está disponible en este momento." }, { status: 503 });
  }
}
