import { createHash } from "node:crypto";
import { NextResponse } from "next/server";
import { z } from "zod";
import { createAdminClient } from "@/lib/supabase/admin";
import { readJsonBody } from "@/lib/request";
import { fetchWompiTransaction, verifyWompiEvent } from "@/lib/wompi";

export const runtime = "nodejs";

const transactionSchema = z
  .object({
    reference: z.string().min(1).max(80),
    id: z.string().min(1).max(120),
    status: z.enum(["PENDING", "APPROVED", "DECLINED", "ERROR", "VOIDED"]),
    amount_in_cents: z.number().int().positive().safe(),
    currency: z.literal("COP"),
  })
  .passthrough();

export async function POST(request: Request) {
  const requestBody = await readJsonBody(request, 262_144);
  if (!requestBody.ok)
    return new NextResponse(requestBody.error, { status: requestBody.status });
  const event = requestBody.value as Record<string, unknown>;
  const isTransactionEvent = event.event === "transaction.updated";
  const requiredProperties = isTransactionEvent
    ? ["transaction.id", "transaction.status", "transaction.amount_in_cents"]
    : [];
  if (
    !verifyWompiEvent(
      event,
      request.headers.get("x-event-checksum"),
      requiredProperties,
    )
  )
    return new NextResponse("Invalid signature", { status: 401 });
  if (event.event !== "transaction.updated")
    return NextResponse.json({ received: true });
  if (
    !event.data ||
    typeof event.data !== "object" ||
    Array.isArray(event.data)
  )
    return new NextResponse("Invalid transaction", { status: 400 });

  const transactionResult = transactionSchema.safeParse(
    (event.data as Record<string, unknown>).transaction,
  );
  if (!transactionResult.success)
    return new NextResponse("Invalid transaction", { status: 400 });
  const transaction = transactionResult.data;
  if (transaction.status === "PENDING")
    return NextResponse.json({ received: true });
  let authoritativeTransaction;
  try {
    authoritativeTransaction = await fetchWompiTransaction(transaction.id);
  } catch {
    // Ask Wompi to retry if its API is unavailable or the server key needs fixing.
    return new NextResponse("Could not verify transaction with Wompi", {
      status: 503,
    });
  }
  if (
    authoritativeTransaction.id !== transaction.id ||
    authoritativeTransaction.reference !== transaction.reference ||
    authoritativeTransaction.status !== transaction.status ||
    authoritativeTransaction.amount_in_cents !== transaction.amount_in_cents ||
    authoritativeTransaction.currency !== transaction.currency
  ) {
    return new NextResponse(
      "Webhook does not match the authoritative transaction",
      { status: 409 },
    );
  }
  const eventKey = createHash("sha256")
    .update(`${transaction.id}:${transaction.status}:${event.timestamp}`)
    .digest("hex");
  const supabase = createAdminClient();
  const { data, error } = await supabase.rpc("settle_wompi_transaction", {
    p_event_key: eventKey,
    p_reference: transaction.reference,
    p_transaction_id: transaction.id,
    p_status: transaction.status,
    p_amount_in_cents: Number(transaction.amount_in_cents),
    p_currency: transaction.currency,
  });
  if (error) return new NextResponse("Could not record event", { status: 500 });
  if (data === false)
    return new NextResponse("Event does not match order", { status: 409 });
  return NextResponse.json({ received: true });
}
