import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = { title: "Política de tratamiento de datos" };
export const dynamic = "force-dynamic";

export default function PrivacyPage() {
  return <main className="policy-page"><Link className="policy-back" href="/">← Volver a la tienda</Link><p className="overline"><span />BORRADOR PARA CONFIGURAR ANTES DEL LANZAMIENTO</p><h1>Tratamiento de<br /><em>datos personales.</em></h1><p className="policy-lead">Este texto es una base editorial para la tienda. El responsable del comercio debe revisarlo y completarlo antes de recibir datos de clientes.</p><section><h2>¿Qué datos se usan?</h2><p>Para gestionar un pedido, el formulario solicita nombre, correo, teléfono, ciudad, dirección de entrega e indicaciones opcionales. La tienda no solicita claves, números de tarjeta ni códigos de seguridad.</p></section><section><h2>¿Para qué se usan?</h2><p>Los datos se usan para registrar el pedido, coordinar la entrega, confirmar el estado del pago y responder solicitudes relacionadas con la compra. El pago se procesa en el checkout alojado por Wompi; este sitio no recibe datos de tarjeta.</p></section><section><h2>Información que debe completar el comercio</h2><ul><li>Razón social o nombre del responsable y NIT.</li><li>Dirección física y correo de contacto para solicitudes de privacidad.</li><li>Finalidades, canales de atención, tiempos de conservación y terceros que procesan datos.</li><li>Procedimiento aplicable para consultas, correcciones y solicitudes de titulares.</li></ul><p className="policy-note">La tienda no debe habilitar pedidos hasta que estos datos y la política definitiva hayan sido revisados por el responsable.</p></section></main>;
}
