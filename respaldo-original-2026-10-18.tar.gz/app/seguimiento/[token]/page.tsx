import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { createHash } from "node:crypto";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  ArrowUpRight,
  Check,
  CircleDot,
  Coffee,
  PackageCheck,
  Truck,
} from "lucide-react";
import { createAdminClient } from "@/lib/supabase/admin";
import { formatCOP } from "@/lib/money";
import { TrackingRefresh } from "@/components/tracking-refresh";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Seguimiento de pedido",
  robots: { index: false, follow: false, noarchive: true },
};

const statusCopy: Record<
  string,
  { title: string; description: string; icon: typeof CircleDot }
> = {
  AWAITING_PAYMENT: {
    title: "Confirmando tu pago",
    description:
      "Estamos esperando la confirmación segura de Wompi. Esta página se actualizará cuando recibamos el evento.",
    icon: CircleDot,
  },
  PAYMENT_REVIEW: {
    title: "Estamos revisando tu pago",
    description:
      "Wompi confirmó el pago y estamos validando una novedad con la disponibilidad. Nuestro equipo te contactará para resolverlo.",
    icon: CircleDot,
  },
  PAID: {
    title: "Pago confirmado",
    description:
      "Gracias por tu compra. Tu pedido ya está en manos de la finca.",
    icon: Check,
  },
  PREPARING: {
    title: "Preparando tu café",
    description: "Estamos alistando tu pedido con todo el cuidado de la casa.",
    icon: Coffee,
  },
  SHIPPED: {
    title: "Tu pedido va en camino",
    description:
      "El paquete salió de la finca. Usa el enlace de rastreo para ver el recorrido.",
    icon: Truck,
  },
  DELIVERED: {
    title: "Entregado con cariño",
    description: "Esperamos que disfrutes mucho cada taza.",
    icon: PackageCheck,
  },
  CANCELLED: {
    title: "Pedido cancelado",
    description:
      "La reserva finalizó o el pago no fue aprobado. Si necesitas ayuda, escríbenos.",
    icon: CircleDot,
  },
  REFUNDED: {
    title: "Devolución en proceso",
    description:
      "El pedido fue reembolsado. Si tienes preguntas sobre el tiempo de reflejo, escríbenos.",
    icon: CircleDot,
  },
};

type TrackingItem = {
  product_name: string;
  variant_label: string;
  grind: string;
  quantity: number;
};
type TrackingEvent = { status: string; message: string; created_at: string };
type TrackingOrder = {
  id: string;
  reference: string;
  status: string;
  total_cop: number;
  city: string;
  created_at: string;
  courier_tracking_url: string | null;
  order_items: TrackingItem[] | null;
  order_events: TrackingEvent[] | null;
};

export default async function TrackingPage({
  params,
}: {
  params: Promise<{ token: string }>;
}) {
  const { token } = await params;
  if (!/^[A-Za-z0-9_-]{40,48}$/.test(token)) notFound();
  const tokenHash = createHash("sha256").update(token).digest("hex");
  let order: TrackingOrder | null = null;
  try {
    const db = createAdminClient();
    const { data } = await db
      .from("orders")
      .select(
        "id,reference,status,total_cop,city,created_at,courier_tracking_url,order_items(product_name,variant_label,grind,quantity),order_events(status,message,created_at)",
      )
      .eq("tracking_token_hash", tokenHash)
      .single();
    order = data as TrackingOrder | null;
  } catch {
    order = null;
  }
  if (!order) notFound();
  const status = statusCopy[order.status] ?? statusCopy.AWAITING_PAYMENT;
  const Icon = status.icon;
  const events = [...(order.order_events ?? [])].sort(
    (a, b) =>
      new Date(b.created_at).getTime() - new Date(a.created_at).getTime(),
  );
  return (
    <main className="tracking-page">
      <header className="tracking-header">
        <Link className="brand" href="/">
          <Image
            src="/assets/logo-cafe-dona-tere.png"
            alt=""
            width={44}
            height={44}
          />
          <span>
            <strong>Café Doña Tere</strong>
            <small>Seguimiento de pedido</small>
          </span>
        </Link>
        <Link className="tracking-back" href="/">
          <ArrowLeft size={15} />
          Volver a la tienda
        </Link>
      </header>
      <section className="tracking-card">
        <div className={`tracking-status status-${order.status.toLowerCase()}`}>
          <Icon size={25} />
        </div>
        <p className="overline">
          <span />
          PEDIDO {order.reference}
        </p>
        <h1>{status.title}</h1>
        <p className="tracking-lead">{status.description}</p>
        {order.status === "AWAITING_PAYMENT" && <TrackingRefresh />}
        {order.courier_tracking_url && order.status === "SHIPPED" && (
          <a
            className="button button-dark"
            href={order.courier_tracking_url}
            target="_blank"
            rel="noreferrer"
          >
            Rastrear con la transportadora <ArrowUpRight size={16} />
          </a>
        )}
        <div className="tracking-rule" />
        <div className="tracking-meta">
          <div>
            <small>FECHA DEL PEDIDO</small>
            <b>
              {new Date(order.created_at).toLocaleDateString("es-CO", {
                dateStyle: "long",
                timeZone: "America/Bogota",
              })}
            </b>
          </div>
          <div>
            <small>DESTINO</small>
            <b>{order.city}</b>
          </div>
          <div>
            <small>TOTAL</small>
            <b>{formatCOP(order.total_cop)}</b>
          </div>
        </div>
        <div className="tracking-items">
          <h2>Tu selección</h2>
          {(order.order_items ?? []).map((item, index: number) => (
            <div key={index}>
              <span>
                {item.quantity} × {item.product_name}
                <small>
                  {item.variant_label} · {item.grind}
                </small>
              </span>
            </div>
          ))}
        </div>
        {events.length > 0 && (
          <div className="tracking-timeline">
            <h2>Actualizaciones</h2>
            {events.map((event, index: number) => (
              <div
                className="timeline-entry"
                key={`${event.status}-${event.created_at}`}
              >
                <span
                  className={
                    index === 0 ? "timeline-dot current" : "timeline-dot"
                  }
                />
                <div>
                  <b>{event.message}</b>
                  <small>
                    {new Date(event.created_at).toLocaleString("es-CO", {
                      dateStyle: "medium",
                      timeStyle: "short",
                      timeZone: "America/Bogota",
                    })}
                  </small>
                </div>
              </div>
            ))}
          </div>
        )}
        <p className="tracking-help">
          ¿Necesitas ayuda?{" "}
          <a
            href="https://wa.me/573124193753"
            target="_blank"
            rel="noopener noreferrer"
          >
            Escríbenos por WhatsApp <ArrowUpRight size={14} />
          </a>
        </p>
      </section>
      <footer className="tracking-footer">
        Café Doña Tere · De nuestra finca a tu mesa
      </footer>
    </main>
  );
}
