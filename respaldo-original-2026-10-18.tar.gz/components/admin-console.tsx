"use client";

import { useState } from "react";
import { PackageCheck, Plus, RefreshCw } from "lucide-react";
import { formatCOP } from "@/lib/money";
import { GRIND_OPTIONS } from "@/lib/grind-options";

type Variant = { id: string; productName: string; label: string; weightGrams: number; priceCop: number; priceConfirmed: boolean; stockOnHand: number; stockReserved: number; grinds: string[] };
type Order = { id: string; reference: string; status: string; payment_review_reason: string | null; customer_name: string; customer_phone: string; customer_email: string; city: string; address: string; delivery_notes: string; total_cop: number; created_at: string; courier_tracking_url: string | null };
type ShippingRate = { city_key: string; city_label: string; price_cop: number; is_active: boolean };

export function InventoryTable({ variants }: { variants: Variant[] }) {
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  async function adjust(event: React.FormEvent<HTMLFormElement>, variantId: string) {
    event.preventDefault(); const form = new FormData(event.currentTarget); setBusy(variantId); setStatus("");
    try {
      const response = await fetch("/api/admin/inventory", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ variantId, delta: Number(form.get("delta")), note: form.get("note") }) });
      const result = await response.json(); if (!response.ok) throw new Error(result.error || "No se pudo actualizar.");
      setStatus("Inventario actualizado."); window.location.reload();
    } catch (error) { setStatus(error instanceof Error ? error.message : "No se pudo actualizar el inventario."); }
    finally { setBusy(null); }
  }
  return <div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Producto</th><th>Presentación</th><th>Precio</th><th>En existencia</th><th>Reservado</th><th>Disponible</th><th>Ajuste</th></tr></thead><tbody>{variants.map((variant) => <tr key={variant.id}><td>{variant.productName}</td><td>{variant.label}</td><td>{variant.priceConfirmed ? formatCOP(variant.priceCop) : <span className="status-pending">Por confirmar</span>}</td><td>{variant.stockOnHand}</td><td>{variant.stockReserved}</td><td><b>{variant.stockOnHand - variant.stockReserved}</b></td><td><form className="inventory-adjust" onSubmit={(event) => adjust(event, variant.id)}><input aria-label="Unidades por ajustar" type="number" name="delta" min={-10000} max={10000} required placeholder="±" /><input aria-label="Motivo del ajuste" name="note" minLength={2} maxLength={200} required placeholder="Motivo" /><button aria-label="Guardar ajuste" disabled={busy === variant.id}><Plus size={15} /></button></form></td></tr>)}</tbody></table>{status && <p className="admin-toast" role="status">{status}</p>}</div>;
}

export function CatalogTable({ variants }: { variants: Variant[] }) {
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  async function save(event: React.FormEvent<HTMLFormElement>, variant: Variant) {
    event.preventDefault(); const form = new FormData(event.currentTarget); setBusy(variant.id); setMessage("");
    try {
      const response = await fetch("/api/admin/catalog", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ variantId: variant.id, label: form.get("label"), weightGrams: Number(form.get("weightGrams")), priceCop: Number(form.get("priceCop")), priceConfirmed: form.get("priceConfirmed") === "on", grinds: form.getAll("grinds") }) });
      const result = await response.json(); if (!response.ok) throw new Error(result.error || "No se pudo guardar.");
      setMessage("Presentación actualizada."); window.location.reload();
    } catch (error) { setMessage(error instanceof Error ? error.message : "No se pudo guardar la presentación."); }
    finally { setBusy(null); }
  }
  return <div className="admin-table-wrap"><table className="admin-table catalog-admin-table"><thead><tr><th>Producto</th><th>Presentación</th><th>Peso (g)</th><th>Precio (COP)</th><th>Precio confirmado</th><th>Guardar</th></tr></thead><tbody>{variants.map((variant) => <tr key={variant.id}><td>{variant.productName}</td><td colSpan={5}><form className="variant-config" onSubmit={(event) => save(event, variant)}><input aria-label="Presentación" name="label" defaultValue={variant.label} maxLength={60} required /><input aria-label="Peso en gramos" name="weightGrams" type="number" min={50} max={20000} defaultValue={variant.weightGrams} required /><input aria-label="Precio en pesos colombianos" name="priceCop" type="number" min={0} max={100000000} step={100} defaultValue={variant.priceCop || ""} placeholder="Precio COP" required /><label className="confirm-price"><input type="checkbox" name="priceConfirmed" defaultChecked={variant.priceConfirmed} /> Confirmar</label><button disabled={busy === variant.id}><RefreshCw size={13} />Guardar</button><fieldset className="grind-admin"><legend>Métodos y moliendas disponibles</legend><div className="grind-admin-grid">{GRIND_OPTIONS.map((option) => <label key={option.value}><input type="checkbox" name="grinds" value={option.value} defaultChecked={variant.grinds.includes(option.value)} /><span><b>{option.method}</b><small>{option.texture}</small></span></label>)}</div></fieldset></form></td></tr>)}</tbody></table>{message && <p className="admin-toast" role="status">{message}</p>}</div>;
}

export function ShippingRatesTable({ rates }: { rates: ShippingRate[] }) {
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  async function save(event: React.FormEvent<HTMLFormElement>, existing?: ShippingRate) {
    event.preventDefault(); const form = new FormData(event.currentTarget); const cityLabel = String(form.get("cityLabel") ?? ""); const key = cityLabel.toLocaleLowerCase(); setBusy(key); setMessage("");
    try {
      const response = await fetch("/api/admin/shipping", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ cityKey: existing?.city_key, cityLabel, priceCop: Number(form.get("priceCop")), active: form.get("active") === "on" }) });
      const result = await response.json(); if (!response.ok) throw new Error(result.error || "No se pudo guardar la tarifa.");
      setMessage("Tarifa guardada."); window.location.reload();
    } catch (error) { setMessage(error instanceof Error ? error.message : "No se pudo guardar la tarifa."); }
    finally { setBusy(null); }
  }
  function row(rate?: ShippingRate) {
    const city = rate?.city_label ?? "";
    const key = rate?.city_key ?? city;
    return <form className="shipping-rate-form" key={key || "new-rate"} onSubmit={(event) => save(event, rate)}><input aria-label="Ciudad o municipio" name="cityLabel" defaultValue={city} maxLength={80} required placeholder="Ciudad o municipio" /><input aria-label="Domicilio en pesos colombianos" type="number" name="priceCop" min={0} max={100000000} defaultValue={rate?.price_cop ?? ""} step={100} required placeholder="COP" /><label className="confirm-price"><input type="checkbox" name="active" defaultChecked={rate?.is_active ?? true} /> Activa</label><button disabled={busy === (city || key).toLocaleLowerCase()}><RefreshCw size={13} />Guardar tarifa</button></form>;
  }
  return <div className="admin-table-wrap shipping-rates"><div className="shipping-rate-intro">Define el domicilio aprobado por destino. La tienda calcula la tarifa en servidor según la ciudad del cliente antes de abrir el pago.</div><div className="shipping-rate-list">{rates.map((rate) => row(rate))}{row()}</div>{message && <p className="admin-toast" role="status">{message}</p>}</div>;
}

export function OrdersTable({ orders }: { orders: Order[] }) {
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  async function setOrderStatus(event: React.FormEvent<HTMLFormElement>, order: Order) {
    event.preventDefault(); const form = new FormData(event.currentTarget); const nextStatus = String(form.get("status")); setBusy(order.id); setStatus("");
    try {
      const response = await fetch("/api/admin/orders", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ orderId: order.id, status: nextStatus, trackingUrl: form.get("trackingUrl") || "" }) });
      const result = await response.json(); if (!response.ok) throw new Error(result.error || "No se pudo actualizar.");
      setStatus("Pedido actualizado."); window.location.reload();
    } catch (error) { setStatus(error instanceof Error ? error.message : "No se pudo actualizar el pedido."); }
    finally { setBusy(null); }
  }
  return <div className="admin-table-wrap"><table className="admin-table orders-table"><thead><tr><th>Pedido</th><th>Cliente y entrega</th><th>Estado</th><th>Total</th><th>Actualización</th></tr></thead><tbody>{orders.map((order) => {
    const nextStatus = order.status === "PAID" || order.status === "PAYMENT_REVIEW" ? "PREPARING" : order.status === "PREPARING" ? "SHIPPED" : "DELIVERED";
    const canUpdate = ["PAID", "PAYMENT_REVIEW", "PREPARING", "SHIPPED"].includes(order.status);
    return <tr key={order.id}><td><b>{order.reference}</b><small>{new Date(order.created_at).toLocaleString("es-CO", { dateStyle: "medium", timeStyle: "short" })}</small></td><td>{order.customer_name}<small>{order.customer_phone} · {order.customer_email}</small><small>{order.address} · {order.city}</small>{order.delivery_notes && <small>Nota: {order.delivery_notes}</small>}</td><td><span className={`order-status status-${order.status.toLowerCase()}`}>{order.status === "PAYMENT_REVIEW" ? "Pago por revisar" : order.status.replaceAll("_", " ")}</span>{order.payment_review_reason && <small className="payment-review-note">{order.payment_review_reason}</small>}</td><td>{formatCOP(order.total_cop)}</td><td>{canUpdate ? <form className="order-update" onSubmit={(event) => setOrderStatus(event, order)}><select name="status" defaultValue={nextStatus}>{order.status === "PAID" && <option value="PREPARING">Preparando</option>}{order.status === "PAYMENT_REVIEW" && <option value="PREPARING">Preparar tras validar stock</option>}{order.status === "PREPARING" && <option value="SHIPPED">Despachado</option>}{order.status === "SHIPPED" && <option value="DELIVERED">Entregado</option>}</select><input type="url" name="trackingUrl" defaultValue={order.courier_tracking_url ?? ""} placeholder="Enlace de rastreo HTTPS" /><button disabled={busy === order.id}><PackageCheck size={15} />Actualizar</button></form> : <span className="muted">Sin acción pendiente</span>}</td></tr>;
  })}</tbody></table>{status && <p className="admin-toast" role="status">{status}</p>}</div>;
}
