"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowRight } from "lucide-react";

export function AdminLoginForm() {
  const router = useRouter();
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError("");
    const data = new FormData(event.currentTarget);
    try {
      const response = await fetch("/api/admin/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email: data.get("email"), password: data.get("password") }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "No se pudo iniciar sesión.");
      router.replace("/admin"); router.refresh();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "No se pudo iniciar sesión."); }
    finally { setBusy(false); }
  }
  return <form className="admin-form" onSubmit={submit}><label>Correo electrónico<input name="email" type="email" autoComplete="username" maxLength={254} required placeholder="admin@tu-dominio.com" /></label><label>Contraseña<input name="password" type="password" autoComplete="current-password" maxLength={256} required placeholder="Tu contraseña" /></label>{error && <p className="admin-form-error" role="alert">{error}</p>}<button className="button button-dark" disabled={busy}>{busy ? "Validando…" : "Entrar al panel"}<ArrowRight size={16} /></button></form>;
}
