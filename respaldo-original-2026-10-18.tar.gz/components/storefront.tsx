"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  Check,
  ChevronDown,
  Coffee,
  Leaf,
  Menu,
  Minus,
  Plus,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  X,
} from "lucide-react";
import type { Product, ProductVariant } from "@/lib/store-types";
import { formatCOP } from "@/lib/money";
import { getGrindOption } from "@/lib/grind-options";

type CartLine = {
  productId: string;
  variantId: string;
  grind: string;
  quantity: number;
};
type Props = { products: Product[]; checkoutEnabled: boolean };

const filters = [
  { id: "all", label: "Todos los cafés" },
  { id: "wood", label: "Tradición a la leña" },
  { id: "precision", label: "Cítrico y dulce" },
  { id: "honey", label: "Microlote Honey" },
] as const;

export function Storefront({ products, checkoutEnabled }: Props) {
  const [filter, setFilter] = useState<string>("all");
  const [cart, setCart] = useState<CartLine[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [checkout, setCheckout] = useState(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [mobileNav, setMobileNav] = useState(false);
  const [variants, setVariants] = useState<Record<string, string>>({});
  const [grinds, setGrinds] = useState<Record<string, string>>({});
  const [checkoutResponse, setCheckoutResponse] = useState<{
    action: string;
    publicKey: string;
    currency: string;
    amountInCents: number;
    reference: string;
    integrity: string;
    redirectUrl: string;
    expirationTime: string;
    subtotalCop: number;
    shippingCop: number;
    totalCop: number;
  } | null>(null);
  const paymentFormRef = useRef<HTMLFormElement>(null);
  const drawerRef = useRef<HTMLElement>(null);
  const returnFocusRef = useRef<HTMLElement | null>(null);
  const [cartLoaded, setCartLoaded] = useState(false);

  useEffect(() => {
    try {
      const saved = JSON.parse(
        localStorage.getItem("cafe-dona-tere-cart-v2") || "[]",
      );
      if (Array.isArray(saved))
        setCart(
          saved
            .filter((line) => {
              if (
                !line ||
                typeof line.productId !== "string" ||
                line.productId.length > 80 ||
                typeof line.variantId !== "string" ||
                line.variantId.length > 80 ||
                typeof line.grind !== "string" ||
                line.grind.length > 40 ||
                !Number.isInteger(line.quantity) ||
                line.quantity < 1 ||
                line.quantity > 10
              )
                return false;
              return products.some(
                (product) =>
                  product.id === line.productId &&
                  product.variants.some(
                    (variant) =>
                      variant.id === line.variantId &&
                      variant.grinds.includes(line.grind),
                  ),
              );
            })
            .slice(0, 10),
        );
    } catch {
      /* Keep the shopping bag available in memory when storage is unavailable. */
    }
    setCartLoaded(true);
  }, [products]);

  useEffect(() => {
    if (cartLoaded) {
      try {
        localStorage.setItem("cafe-dona-tere-cart-v2", JSON.stringify(cart));
      } catch {
        /* The current visit still works without browser storage. */
      }
    }
  }, [cart, cartLoaded]);

  useEffect(() => {
    setCheckoutResponse(null);
  }, [cart]);

  useEffect(() => {
    if (!cartOpen) return;
    const hadScrollLock =
      document.documentElement.classList.contains("cart-scroll-locked");
    document.documentElement.classList.add("cart-scroll-locked");
    drawerRef.current?.querySelector<HTMLElement>(".close-drawer")?.focus();
    function handleDrawerKey(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setCartOpen(false);
        setCheckout(false);
        return;
      }
      if (event.key !== "Tab" || !drawerRef.current) return;
      const focusable = [
        ...drawerRef.current.querySelectorAll<HTMLElement>(
          "a[href],button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled)",
        ),
      ].filter((node) => node.offsetParent !== null);
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }
    document.addEventListener("keydown", handleDrawerKey);
    return () => {
      document.removeEventListener("keydown", handleDrawerKey);
      if (!hadScrollLock)
        document.documentElement.classList.remove("cart-scroll-locked");
      if (returnFocusRef.current?.isConnected) returnFocusRef.current.focus();
    };
  }, [cartOpen]);

  const visibleProducts = useMemo(
    () =>
      filter === "all"
        ? products
        : products.filter((product) => product.category === filter),
    [filter, products],
  );
  const lines = cart
    .map((line) => {
      const product = products.find(
        (candidate) => candidate.id === line.productId,
      );
      const variant = product?.variants.find(
        (candidate) => candidate.id === line.variantId,
      );
      return product && variant ? { ...line, product, variant } : null;
    })
    .filter(
      (
        line,
      ): line is CartLine & { product: Product; variant: ProductVariant } =>
        Boolean(line),
    );
  const totalItems = lines.reduce((sum, line) => sum + line.quantity, 0);
  const subtotal = lines.reduce(
    (sum, line) => sum + line.variant.priceCop * line.quantity,
    0,
  );

  function currentVariant(product: Product) {
    return (
      product.variants.find((variant) => variant.id === variants[product.id]) ??
      product.variants[0]
    );
  }

  function addToCart(product: Product) {
    const variant = currentVariant(product);
    if (!variant) return;
    returnFocusRef.current =
      document.activeElement instanceof HTMLElement
        ? document.activeElement
        : null;
    const grind = grinds[product.id] ?? variant.grinds[0] ?? "Molido";
    const line = cart.find(
      (item) => item.variantId === variant.id && item.grind === grind,
    );
    if (line && line.quantity >= 10) {
      setNotice(
        "Puedes agregar hasta 10 unidades de esta presentación por pedido.",
      );
      window.setTimeout(() => setNotice(""), 2400);
      return;
    }
    setCart((current) => {
      const existing = current.find(
        (line) => line.variantId === variant.id && line.grind === grind,
      );
      return existing
        ? current.map((line) =>
            line === existing ? { ...line, quantity: line.quantity + 1 } : line,
          )
        : [
            ...current,
            {
              productId: product.id,
              variantId: variant.id,
              grind,
              quantity: 1,
            },
          ];
    });
    setNotice(`${product.name} está en tu bolsa`);
    setCartOpen(true);
    window.setTimeout(() => setNotice(""), 2400);
  }

  function updateQuantity(variantId: string, grind: string, delta: number) {
    const existing = cart.find(
      (line) => line.variantId === variantId && line.grind === grind,
    );
    if (delta > 0 && existing && existing.quantity >= 10) {
      setNotice(
        "Puedes agregar hasta 10 unidades de esta presentación por pedido.",
      );
      window.setTimeout(() => setNotice(""), 2400);
      return;
    }
    setCart((current) =>
      current
        .map((line) =>
          line.variantId === variantId && line.grind === grind
            ? { ...line, quantity: line.quantity + delta }
            : line,
        )
        .filter((line) => line.quantity > 0),
    );
  }

  async function startCheckout(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setNotice("");
    const form = new FormData(event.currentTarget);
    const customer = Object.fromEntries(
      ["name", "email", "phone", "city", "address", "notes"].map((key) => [
        key,
        String(form.get(key) ?? "").trim(),
      ]),
    );
    const privacyConsent = form.get("privacyConsent") === "accepted";
    try {
      const response = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customer,
          privacyConsent,
          items: lines.map(({ variant, grind, quantity }) => ({
            variantId: variant.id,
            grind,
            quantity,
          })),
        }),
      });
      const result = await response.json();
      if (!response.ok)
        throw new Error(result.error || "No fue posible iniciar el pedido.");
      setCheckoutResponse({
        ...result.checkout,
        subtotalCop: result.subtotalCop,
        shippingCop: result.shippingCop,
        totalCop: result.totalCop,
      });
      setNotice(
        "El total está listo. Revisa el resumen y continúa al checkout seguro.",
      );
    } catch (error) {
      setNotice(
        error instanceof Error
          ? error.message
          : "No fue posible iniciar el pedido.",
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <a className="skip-link" href="#cafes">
        Saltar al catálogo
      </a>
      <div className="topline">
        <span>
          <Sparkles size={13} /> Café de origen · Finca La Libertad, Cachipay
        </span>
        <a href="#origen">
          Conoce nuestra historia <ArrowUpRight size={14} />
        </a>
      </div>
      <header className="site-header">
        <Link
          className="brand"
          href="#inicio"
          aria-label="Café Doña Tere, inicio"
        >
          <Image
            src="/assets/logo-cafe-dona-tere.png"
            alt=""
            width={52}
            height={52}
            priority
          />
          <span>
            <strong>Café Doña Tere</strong>
            <small>De nuestra finca a tu mesa</small>
          </span>
        </Link>
        <button
          className="mobile-menu"
          aria-label={mobileNav ? "Cerrar menú" : "Abrir menú"}
          aria-expanded={mobileNav}
          aria-controls="main-nav"
          onClick={() => setMobileNav(!mobileNav)}
        >
          {mobileNav ? <X /> : <Menu />}
        </button>
        <nav
          className={mobileNav ? "main-nav is-open" : "main-nav"}
          id="main-nav"
          aria-label="Navegación principal"
        >
          <a href="#cafes" onClick={() => setMobileNav(false)}>
            Nuestros cafés
          </a>
          <a href="#origen" onClick={() => setMobileNav(false)}>
            La finca
          </a>
          <a href="#guia" onClick={() => setMobileNav(false)}>
            Guía de sabor
          </a>
          <a href="#preguntas" onClick={() => setMobileNav(false)}>
            Ayuda
          </a>
        </nav>
        <div className="header-actions">
          <button
            className="bag-button"
            type="button"
            aria-expanded={cartOpen}
            aria-controls="cart-drawer"
            onClick={(event) => {
              returnFocusRef.current = event.currentTarget;
              setCartOpen(true);
            }}
          >
            <ShoppingBag size={18} />
            <span>Mi bolsa</span>
            <b>{totalItems}</b>
          </button>
        </div>
      </header>

      <main id="inicio">
        <section className="hero-shell">
          <div className="hero-copy">
            <p className="overline">
              <span />
              Una historia familiar, servida en cada taza
            </p>
            <h1>
              El origen se siente.
              <br />
              <em>El cariño también.</em>
            </h1>
            <p className="hero-lead">
              Café colombiano cultivado en Cachipay, tostado con calma y
              preparado para acompañar los momentos que importan.
            </p>
            <div className="hero-buttons">
              <a className="button button-dark" href="#cafes">
                Descubrir cafés <ArrowRight size={17} />
              </a>
              <a className="underlined-link" href="#origen">
                Nuestra finca <ArrowUpRight size={15} />
              </a>
            </div>
            <div className="hero-proof">
              <div>
                <b>100%</b>
                <span>café colombiano</span>
              </div>
              <i />
              <div>
                <b>Cachipay</b>
                <span>Cundinamarca</span>
              </div>
              <i />
              <div>
                <b>Con calma</b>
                <span>desde la finca</span>
              </div>
            </div>
          </div>
          <div className="hero-art">
            <div className="hero-photo">
              <Image
                src="/assets/roasting.jpg"
                alt="Preparación artesanal del café de Finca La Libertad"
                fill
                preload
                sizes="(max-width: 800px) 100vw, 54vw"
              />
            </div>
            <div className="hero-inset-photo">
              <Image
                src="/assets/beans.jpg"
                alt="Granos tostados seleccionados en la finca"
                fill
                sizes="150px"
              />
              <span>El cuidado, lote a lote</span>
            </div>
            <div className="hero-stamp">
              <span>
                CAFÉ DE
                <br />
                ORIGEN
              </span>
              <b>✳</b>
              <small>CACHIPAY · COLOMBIA</small>
            </div>
            <div className="hero-note">
              <span className="note-icon">
                <Coffee size={19} />
              </span>
              <span>
                <small>EL RITUAL DE LA CASA</small>
                <b>
                  Tostado con calma.
                  <br />
                  Compartido con cariño.
                </b>
              </span>
            </div>
            <span className="image-caption">
              FINCA LA LIBERTAD · CUNDINAMARCA
            </span>
          </div>
          <a className="scroll-cue" href="#cafes">
            <span>Desliza para explorar</span>
            <ArrowDown size={15} />
          </a>
        </section>

        <section
          className="promise-strip"
          aria-label="Beneficios de Café Doña Tere"
        >
          <div>
            <span className="promise-icon">
              <Leaf />
            </span>
            <span>
              <b>Origen que puedes conocer</b>
              <small>Finca La Libertad · Cachipay</small>
            </span>
          </div>
          <div>
            <span className="promise-icon">
              <Coffee />
            </span>
            <span>
              <b>Perfiles para cada gusto</b>
              <small>Escoge tu próxima taza favorita</small>
            </span>
          </div>
          <div>
            <span className="promise-icon">
              <ShieldCheck />
            </span>
            <span>
              <b>
                {checkoutEnabled ? "Compra protegida" : "Pagos en preparación"}
              </b>
              <small>
                {checkoutEnabled
                  ? "Pago seguro con Wompi"
                  : "Checkout seguro al habilitar la tienda"}
              </small>
            </span>
          </div>
        </section>

        <section className="catalog-section" id="cafes">
          <div className="section-shell">
            <div className="section-intro">
              <div>
                <p className="overline">
                  <span />
                  Selección de la finca
                </p>
                <h2>
                  Un café para cada
                  <br />
                  <em>forma de disfrutar.</em>
                </h2>
              </div>
              <p>
                Del carácter ahumado de la leña a una taza cítrica y dulce.
                Encuentra el perfil que se siente como tuyo.
              </p>
            </div>
            <div className="catalog-toolbar">
              <div
                className="filter-row"
                role="group"
                aria-label="Filtrar cafés"
              >
                {filters.map((item) => (
                  <button
                    key={item.id}
                    className={
                      filter === item.id ? "filter-pill active" : "filter-pill"
                    }
                    type="button"
                    aria-pressed={filter === item.id}
                    onClick={() => setFilter(item.id)}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
              <span className="catalog-count">
                {visibleProducts.length.toString().padStart(2, "0")} perfiles
              </span>
            </div>
            {visibleProducts.length === 0 ? (
              <div className="catalog-empty">
                <Coffee size={24} />
                <h3>Estamos preparando la próxima selección.</h3>
                <p>
                  Estamos actualizando la disponibilidad de la finca. Mientras
                  tanto, cuéntanos qué café buscas.
                </p>
                <a
                  href="https://wa.me/573124193753"
                  target="_blank"
                  rel="noreferrer"
                >
                  Consultar por WhatsApp <ArrowUpRight size={15} />
                </a>
              </div>
            ) : (
              <div className="product-grid">
                {visibleProducts.map((product, index) => {
                  const variant = currentVariant(product);
                  if (!variant) return null;
                  const preferredGrind = grinds[product.id] ?? "";
                  const selectedGrind = variant.grinds.includes(preferredGrind)
                    ? preferredGrind
                    : (variant.grinds[0] ?? "Molido");
                  const selectedGrindOption = getGrindOption(selectedGrind);
                  const visualImage =
                    variant.id === "lena-500" && selectedGrind === "En grano"
                      ? variant.image.replace(
                          "cafe-lena-500-ground-front.jpg",
                          "cafe-lena-500-beans-front.jpg",
                        )
                      : variant.image;
                  const hasPackageArtwork = visualImage.endsWith("-front.jpg");
                  const price = variant.priceConfirmed
                    ? formatCOP(variant.priceCop)
                    : variant.priceCop
                      ? `≈ ${formatCOP(variant.priceCop)}`
                      : "Precio por confirmar";
                  const soldOut = checkoutEnabled && variant.stock <= 0;
                  const priceUnavailable =
                    checkoutEnabled &&
                    (!variant.priceConfirmed || variant.priceCop <= 0);
                  const orderUnavailable = soldOut || priceUnavailable;
                  return (
                    <article
                      key={product.id}
                      className={`product-card product-card-${product.category}`}
                    >
                      <div
                        className={`product-visual ${hasPackageArtwork ? "has-package" : "has-photo"}`}
                      >
                        {hasPackageArtwork ? (
                          <>
                            <Image
                              src={product.image}
                              alt=""
                              aria-hidden="true"
                              fill
                              sizes="(max-width: 700px) 95vw, (max-width: 1100px) 45vw, 30vw"
                              className="product-photo-backdrop"
                            />
                            <div className="product-pack" aria-hidden="true">
                              <Image
                              src={visualImage}
                                alt=""
                                fill
                                sizes="(max-width: 700px) 38vw, 15vw"
                              />
                            </div>
                          </>
                        ) : (
                          <Image
                            src={visualImage}
                            alt={`${product.name}, café de Finca La Libertad`}
                            fill
                            sizes="(max-width: 700px) 95vw, (max-width: 1100px) 45vw, 30vw"
                            className="product-feature-photo"
                          />
                        )}
                        <span className="product-tag">
                          <Sparkles size={12} />
                          {product.badge}
                        </span>
                        <span className="product-index">
                          0{index + 1} / CAFÉ DE FINCA
                        </span>
                        <button
                          className="quick-add"
                          disabled={orderUnavailable}
                          aria-label={
                            soldOut
                              ? `${product.name} agotado`
                              : priceUnavailable
                                ? `Precio pendiente para ${product.name}`
                                : `Agregar ${product.name} a la bolsa`
                          }
                          onClick={() => addToCart(product)}
                        >
                          <Plus />
                        </button>
                      </div>
                      <div className="product-info">
                        <p className="product-subtitle">{product.subtitle}</p>
                        <div className="product-title-line">
                          <h3>{product.name}</h3>
                          <span>{price}</span>
                        </div>
                        <p className="product-description">
                          {product.description}
                        </p>
                        <div className="tasting-notes">
                          {product.notes.map((note) => (
                            <span key={note}>{note}</span>
                          ))}
                        </div>
                        <div className="variant-row">
                          <label>
                            <span>Presentación</span>
                            <div className="select-wrap">
                              <select
                                value={variant.id}
                                onChange={(event) => {
                                  setVariants((state) => ({
                                    ...state,
                                    [product.id]: event.target.value,
                                  }));
                                  const next = product.variants.find(
                                    (item) => item.id === event.target.value,
                                  );
                                  if (next)
                                    setGrinds((state) => ({
                                      ...state,
                                      [product.id]: next.grinds[0],
                                    }));
                                }}
                                aria-label={`Presentación de ${product.name}`}
                              >
                                {product.variants.map((item) => (
                                  <option key={item.id} value={item.id}>
                                    {item.label}
                                  </option>
                                ))}
                              </select>
                              <ChevronDown size={15} />
                            </div>
                          </label>
                          <label className="grind-field">
                            <span>Tu método de preparación</span>
                            {variant.grinds.length > 1 ? (
                              <div className="select-wrap">
                                <select
                                  value={selectedGrind}
                                  onChange={(event) =>
                                    setGrinds((state) => ({
                                      ...state,
                                      [product.id]: event.target.value,
                                    }))
                                  }
                                  aria-label={`Método de preparación y molienda de ${product.name}`}
                                >
                                  {variant.grinds.map((grind) => (
                                    <option key={grind} value={grind}>
                                      {getGrindOption(grind).method} · {getGrindOption(grind).texture}
                                    </option>
                                  ))}
                                </select>
                                <ChevronDown size={15} />
                              </div>
                            ) : (
                              <div className="fixed-value">
                                {selectedGrindOption.method} · {selectedGrindOption.texture}
                              </div>
                            )}
                          </label>
                        </div>
                        <p className="grind-guidance">
                          <Coffee size={14} aria-hidden="true" />
                          <span>{selectedGrindOption.description}</span>
                        </p>
                        <button
                          className="product-cta"
                          disabled={orderUnavailable}
                          onClick={() => addToCart(product)}
                        >
                          <span>
                            {soldOut
                              ? "Agotado por ahora"
                              : priceUnavailable
                                ? "Precio por confirmar"
                                : "Agregar a la bolsa"}
                          </span>
                          <ArrowUpRight size={17} />
                        </button>
                        {soldOut && (
                          <p className="stock-note">
                            Te avisaremos cuando vuelva a estar disponible.
                          </p>
                        )}
                        {!variant.priceConfirmed && (
                          <p className="reference-note">
                            {variant.priceCop
                              ? "Precio de referencia, pendiente de confirmación"
                              : "Precio y disponibilidad por confirmar"}
                          </p>
                        )}
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
            <div className="price-disclosure">
              <span>i</span>
              <p>
                <b>Estamos afinando los detalles de nuestra tienda.</b> Algunos
                precios y presentaciones aún son referencias de materiales
                previos. Confirmaremos valores, disponibilidad, domicilio y
                molienda antes de habilitar el cobro.
              </p>
            </div>
          </div>
        </section>

        <section className="origin-section" id="origen">
          <div className="origin-photo">
            <Image
              src="/assets/beans-closeup.jpg"
              alt="Granos de café seleccionados en Finca La Libertad"
              fill
              sizes="(max-width: 780px) 100vw, 52vw"
            />
            <div className="origin-photo-caption">
              <span>Finca La Libertad</span>
              <i />
              Cachipay, Cundinamarca
            </div>
          </div>
          <div className="origin-copy">
            <p className="overline light">
              <span />
              Una historia que se comparte
            </p>
            <h2>
              El mejor café
              <br />
              también sabe a <em>casa.</em>
            </h2>
            <p>
              Doña Tere es una tradición familiar convertida en café. Cultivamos
              en las montañas de Cachipay y cuidamos cada paso para que el
              origen se encuentre con tus momentos de todos los días.
            </p>
            <div className="origin-signature">
              <div className="signature-mark">T</div>
              <span>
                <b>Desde Finca La Libertad</b>
                <small>Cundinamarca · Colombia</small>
              </span>
              <span className="signature-flower">✳</span>
            </div>
            <a className="light-link" href="#guia">
              Explora los perfiles <ArrowUpRight size={16} />
            </a>
            <div className="altitude-mark">
              <b>1.450–1.650</b>
              <span>metros sobre el nivel del mar</span>
            </div>
          </div>
        </section>

        <section className="guide-section" id="guia">
          <div className="guide-heading">
            <p className="overline">
              <span />
              Una guía para elegir
            </p>
            <h2>
              Encuentra tu forma
              <br />
              de disfrutar el <em>café.</em>
            </h2>
            <p>
              Un buen punto de partida es pensar en los sabores que más
              disfrutas.
            </p>
          </div>
          <div className="guide-cards">
            <article>
              <span>01</span>
              <div className="guide-orbit orbit-wood">
                <b>cacao</b>
              </div>
              <h3>¿Te gustan las tazas intensas?</h3>
              <p>
                Empieza por el tostado a la leña: cacao, frutos secos y un final
                ahumado.
              </p>
              <a href="#cafes" onClick={() => setFilter("wood")}>
                Ver tradición a la leña <ArrowRight size={15} />
              </a>
            </article>
            <article>
              <span>02</span>
              <div className="guide-orbit orbit-citrus">
                <b>cítricos</b>
              </div>
              <h3>¿Prefieres dulzor y frescura?</h3>
              <p>
                La tostión de precisión resalta notas cítricas, panela y
                almendra.
              </p>
              <a href="#cafes" onClick={() => setFilter("precision")}>
                Ver perfil cítrico <ArrowRight size={15} />
              </a>
            </article>
            <article>
              <span>03</span>
              <div className="guide-orbit orbit-honey">
                <b>descubre</b>
              </div>
              <h3>¿Quieres probar algo distinto?</h3>
              <p>
                Conoce el microlote Honey y la expresión de un proceso especial.
              </p>
              <a href="#cafes" onClick={() => setFilter("honey")}>
                Ver microlote Honey <ArrowRight size={15} />
              </a>
            </article>
          </div>
        </section>

        <section className="craft-banner">
          <div className="craft-art">
            <Image
              src="/assets/classic-500-beans.jpg"
              alt="Empaque del café tostado a la leña"
              fill
              sizes="(max-width: 700px) 100vw, 40vw"
            />
          </div>
          <div className="craft-copy">
            <p className="overline">
              <span />
              El cuidado está en los detalles
            </p>
            <h2>
              De la finca,
              <br />
              <em>con intención.</em>
            </h2>
            <p>
              Cuidamos el grano, el tueste y cada presentación para que el
              carácter de La Libertad llegue a tu casa como debe ser.
            </p>
            <div className="craft-points">
              <span>
                <i>01</i>Origen colombiano
              </span>
              <span>
                <i>02</i>Perfiles de la finca
              </span>
              <span>
                <i>03</i>Preparado a tu manera
              </span>
            </div>
          </div>
        </section>

        <section className="faq-section" id="preguntas">
          <div className="faq-intro">
            <p className="overline">
              <span />
              Estamos para ayudarte
            </p>
            <h2>
              Preguntas
              <br />
              <em>frecuentes.</em>
            </h2>
            <p>
              ¿Tienes una pregunta sobre el café, las presentaciones o tu
              pedido?
            </p>
            <a
              className="underlined-link"
              href="https://wa.me/573124193753"
              target="_blank"
              rel="noreferrer"
            >
              Hablemos por WhatsApp <ArrowUpRight size={15} />
            </a>
          </div>
          <div className="faq-list">
            <details>
              <summary>
                ¿De dónde viene el café?<span>+</span>
              </summary>
              <p>
                De Finca La Libertad, en Cachipay, Cundinamarca. Una tradición
                familiar que cultivamos y compartimos desde las montañas
                colombianas.
              </p>
            </details>
            <details>
              <summary>
                ¿Puedo escoger el tipo de molienda?<span>+</span>
              </summary>
              <p>
                Puedes elegir una molienda pensada para espresso, moka, V60 y
                filtros, Chemex, prensa francesa, AeroPress o cold brew. Las
                opciones dependen de cada presentación; también verás café en
                grano cuando esté disponible.
              </p>
            </details>
            <details>
              <summary>
                ¿Cuánto cuesta el envío?<span>+</span>
              </summary>
              <p>
                El valor depende de la ciudad y la dirección. Confirmaremos el
                domicilio y el total contigo antes de habilitar el pago.
              </p>
            </details>
            <details>
              <summary>
                ¿Qué medios de pago tendrá la tienda?<span>+</span>
              </summary>
              <p>
                La tienda está diseñada para integrar Wompi. El comercio podrá
                habilitar los medios disponibles para su cuenta, como tarjetas,
                PSE y otros métodos autorizados.
              </p>
            </details>
          </div>
        </section>
        <section className="closing-cta">
          <div>
            <span>UNA BUENA TAZA CAMBIA EL MOMENTO</span>
            <h2>
              El origen está
              <br />
              más cerca de lo que <em>imaginas.</em>
            </h2>
            <a className="button button-cream" href="#cafes">
              Encuentra tu café <ArrowRight size={17} />
            </a>
          </div>
          <span className="closing-star">✳</span>
        </section>
      </main>

      <footer className="site-footer">
        <div className="footer-top">
          <Link className="brand brand-footer" href="#inicio">
            <Image
              src="/assets/logo-cafe-dona-tere.png"
              alt=""
              width={46}
              height={46}
            />
            <span>
              <strong>Café Doña Tere</strong>
              <small>De nuestra finca a tu mesa</small>
            </span>
          </Link>
          <p>
            Un café de finca, tostado con calma
            <br />y hecho para compartirlo contigo.
          </p>
          <div>
            <span>¿Te ayudamos a elegir?</span>
            <a
              href="https://wa.me/573124193753"
              target="_blank"
              rel="noreferrer"
            >
              Escríbenos <ArrowUpRight size={14} />
            </a>
          </div>
        </div>
        <div className="footer-bottom">
          <span>
            © {new Date().getFullYear()} Café Doña Tere · Cachipay, Colombia
          </span>
          <span>
            Origen colombiano <i>✳</i> Hecho con cariño
          </span>
          <Link href="/privacidad">Datos personales</Link>
          <Link href="#inicio">Volver al inicio ↑</Link>
        </div>
      </footer>

      <div
        className={cartOpen ? "drawer-backdrop visible" : "drawer-backdrop"}
        onClick={() => {
          setCartOpen(false);
          setCheckout(false);
        }}
      />
      <aside
        ref={drawerRef}
        id="cart-drawer"
        className={cartOpen ? "cart-drawer is-open" : "cart-drawer"}
        role="dialog"
        aria-modal="true"
        aria-label="Tu bolsa"
        aria-hidden={!cartOpen}
        inert={!cartOpen}
      >
        <div className="drawer-head">
          <div>
            <p className="overline">
              <span />
              TU SELECCIÓN
            </p>
            <h2>
              Tu bolsa <small>({totalItems})</small>
            </h2>
          </div>
          <button
            className="close-drawer"
            aria-label="Cerrar bolsa"
            onClick={() => {
              setCartOpen(false);
              setCheckout(false);
            }}
          >
            <X />
          </button>
        </div>
        {lines.length === 0 ? (
          <div className="empty-cart">
            <span className="empty-cup">
              <Coffee />
            </span>
            <h3>Tu bolsa está esperando.</h3>
            <p>Escoge un café de La Libertad para empezar.</p>
            <button
              className="button button-dark"
              onClick={() => setCartOpen(false)}
            >
              Ver cafés <ArrowRight size={16} />
            </button>
          </div>
        ) : (
          <>
            <div className="drawer-content">
              {lines.map((line) => (
                <article
                  className="cart-line"
                  key={`${line.variant.id}-${line.grind}`}
                >
                  <div className="cart-line-image">
                    <Image src={line.variant.image} alt="" fill sizes="92px" />
                  </div>
                  <div className="cart-line-body">
                    <div className="cart-line-title">
                      <div>
                        <b>{line.product.name}</b>
                        <small>
                          {line.variant.label} · {line.grind}
                        </small>
                      </div>
                      <strong>
                        {line.variant.priceCop
                          ? formatCOP(line.variant.priceCop * line.quantity)
                          : "Por confirmar"}
                      </strong>
                    </div>
                    <div className="qty-stepper">
                      <button
                        aria-label="Quitar unidad"
                        onClick={() =>
                          updateQuantity(line.variant.id, line.grind, -1)
                        }
                      >
                        <Minus size={13} />
                      </button>
                      <span>{line.quantity}</span>
                      <button
                        aria-label="Agregar unidad"
                        onClick={() =>
                          updateQuantity(line.variant.id, line.grind, 1)
                        }
                      >
                        <Plus size={13} />
                      </button>
                      <button
                        className="remove-line"
                        onClick={() =>
                          setCart((current) =>
                            current.filter(
                              (item) =>
                                item.variantId !== line.variant.id ||
                                item.grind !== line.grind,
                            ),
                          )
                        }
                      >
                        Quitar
                      </button>
                    </div>
                  </div>
                </article>
              ))}
              {checkout && (
                <form className="checkout-form" onSubmit={startCheckout}>
                  <p className="overline">
                    <span />
                    ENVÍO Y CONTACTO
                  </p>
                  <h3>¿A dónde llevamos tu café?</h3>
                  <fieldset
                    className="checkout-fieldset"
                    disabled={Boolean(checkoutResponse)}
                  >
                    <div className="checkout-fields">
                      <label>
                        Nombre completo
                        <input
                          name="name"
                          autoComplete="name"
                          minLength={2}
                          maxLength={100}
                          required
                          placeholder="Tu nombre"
                        />
                      </label>
                      <label>
                        Correo electrónico
                        <input
                          name="email"
                          type="email"
                          autoComplete="email"
                          maxLength={254}
                          required
                          placeholder="nombre@correo.com"
                        />
                      </label>
                      <label>
                        Celular
                        <input
                          name="phone"
                          type="tel"
                          autoComplete="tel"
                          inputMode="tel"
                          minLength={7}
                          maxLength={20}
                          required
                          placeholder="300 000 0000"
                        />
                      </label>
                      <label>
                        Ciudad o municipio
                        <input
                          name="city"
                          autoComplete="address-level2"
                          maxLength={80}
                          required
                          placeholder="Ej. Bogotá"
                        />
                      </label>
                      <label className="field-full">
                        Dirección de entrega
                        <input
                          name="address"
                          autoComplete="street-address"
                          maxLength={180}
                          required
                          placeholder="Calle, carrera y número"
                        />
                      </label>
                      <label className="field-full">
                        Indicaciones <small>(opcional)</small>
                        <textarea
                          name="notes"
                          rows={2}
                          maxLength={300}
                          placeholder="Barrio, apartamento o referencia"
                        />
                      </label>
                    </div>
                    <label className="privacy-check">
                      <input
                        name="privacyConsent"
                        type="checkbox"
                        value="accepted"
                        required
                      />
                      <span>
                        He leído y autorizo el tratamiento de estos datos para
                        gestionar mi pedido y la entrega.{" "}
                        <a
                          href="/privacidad"
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          Política de privacidad
                        </a>
                      </span>
                    </label>
                  </fieldset>
                  {!checkoutEnabled && (
                    <p className="setup-message">
                      La tienda está en etapa de configuración. El pago se
                      habilitará cuando el comercio confirme precios,
                      inventario, tarifas y condiciones de privacidad.
                    </p>
                  )}
                  {checkoutResponse ? (
                    <div className="payment-confirmation">
                      <div>
                        <span>Productos</span>
                        <b>{formatCOP(checkoutResponse.subtotalCop)}</b>
                      </div>
                      <div>
                        <span>Domicilio</span>
                        <b>
                          {checkoutResponse.shippingCop
                            ? formatCOP(checkoutResponse.shippingCop)
                            : "Incluido"}
                        </b>
                      </div>
                      <div className="payment-total">
                        <span>Total a pagar</span>
                        <b>{formatCOP(checkoutResponse.totalCop)}</b>
                      </div>
                      <button
                        type="button"
                        className="button button-dark checkout-submit"
                        onClick={() => paymentFormRef.current?.requestSubmit()}
                      >
                        Pagar con Wompi <ArrowRight size={16} />
                      </button>
                    </div>
                  ) : (
                    <button
                      className="button button-dark checkout-submit"
                      disabled={busy || !checkoutEnabled}
                    >
                      {busy
                        ? "Preparando pedido…"
                        : checkoutEnabled
                          ? "Calcular total y continuar"
                          : "Pagos en preparación"}
                      <ArrowRight size={16} />
                    </button>
                  )}
                  {notice && (
                    <p className="checkout-notice" role="status">
                      {notice}
                    </p>
                  )}
                </form>
              )}
            </div>
            <div className="drawer-summary">
              <div>
                <span>
                  {lines.some(
                    (line) =>
                      !line.variant.priceConfirmed ||
                      line.variant.priceCop <= 0,
                  )
                    ? "Subtotal de referencia"
                    : "Subtotal"}
                </span>
                <b>
                  {subtotal
                    ? `${lines.some((line) => !line.variant.priceConfirmed) ? "≈ " : ""}${formatCOP(subtotal)}`
                    : "Por confirmar"}
                </b>
              </div>
              <p>
                El domicilio se calcula con la tarifa configurada para tu
                ciudad; verás el total antes de ir al pago.
              </p>
              {checkout ? (
                <button
                  className="text-button"
                  onClick={() => setCheckout(false)}
                >
                  Volver a la bolsa
                </button>
              ) : (
                <button
                  className="button button-dark checkout-start"
                  onClick={() => setCheckout(true)}
                >
                  Continuar pedido <ArrowRight size={16} />
                </button>
              )}
            </div>
          </>
        )}
      </aside>
      {checkoutResponse && (
        <form
          ref={paymentFormRef}
          action={checkoutResponse.action}
          method="GET"
          hidden
        >
          <input
            name="public-key"
            value={checkoutResponse.publicKey}
            readOnly
          />
          <input name="currency" value={checkoutResponse.currency} readOnly />
          <input
            name="amount-in-cents"
            value={checkoutResponse.amountInCents}
            readOnly
          />
          <input name="reference" value={checkoutResponse.reference} readOnly />
          <input
            name="signature:integrity"
            value={checkoutResponse.integrity}
            readOnly
          />
          <input
            name="redirect-url"
            value={checkoutResponse.redirectUrl}
            readOnly
          />
          <input
            name="expiration-time"
            value={checkoutResponse.expirationTime}
            readOnly
          />
        </form>
      )}
      {notice && (
        <div className="toast-message" role="status">
          <Check size={15} />
          {notice}
        </div>
      )}
    </>
  );
}
