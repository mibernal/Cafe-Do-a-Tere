"use client";

import { RefreshCw } from "lucide-react";

export function TrackingRefresh() {
  return <button className="tracking-refresh" onClick={() => window.location.reload()}><RefreshCw size={15} />Actualizar estado</button>;
}
