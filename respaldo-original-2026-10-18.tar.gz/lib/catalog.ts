import "server-only";
import { createClient } from "@supabase/supabase-js";
import type { Product } from "@/lib/store-types";
import { GROUND_GRIND_VALUES } from "@/lib/grind-options";

export const previewCatalog: Product[] = [
  {
    id: "lena",
    slug: "tostado-a-la-lena",
    category: "wood",
    name: "Tostado a la leña",
    subtitle: "La tradición de la casa",
    description: "Cacao oscuro, frutos secos y una nota cítrica suave que termina con el carácter inconfundible de la leña.",
    process: "Tostión a la leña",
    origin: "Finca La Libertad · Cachipay",
    altitude: "1.450–1.650 m s. n. m.",
    notes: ["Cacao", "Frutos secos", "Final ahumado"],
    badge: "El favorito de casa",
    image: "/assets/beans.jpg",
    published: true,
    variants: [
      { id: "lena-250", label: "250 g", weightGrams: 250, priceCop: 0, priceConfirmed: false, stock: 0, grinds: [...GROUND_GRIND_VALUES], image: "/assets/cafe-lena-250-front.jpg" },
      { id: "lena-500", label: "500 g", weightGrams: 500, priceCop: 40000, priceConfirmed: false, stock: 0, grinds: [...GROUND_GRIND_VALUES, "En grano"], image: "/assets/cafe-lena-500-ground-front.jpg" },
    ],
  },
  {
    id: "precision",
    slug: "tostion-de-precision",
    category: "precision",
    name: "Tostión de precisión",
    subtitle: "Una taza luminosa y dulce",
    description: "Un perfil amable de naranja y mandarina, acompañado por panela, almendra y chocolate con leche.",
    process: "Tostión media",
    origin: "Finca La Libertad · Cachipay",
    altitude: "Altura por confirmar",
    notes: ["Naranja", "Panela", "Almendra"],
    badge: "Perfil de taza",
    image: "/assets/roasting.jpg",
    published: true,
    variants: [
      { id: "precision-500", label: "500 g", weightGrams: 500, priceCop: 0, priceConfirmed: false, stock: 0, grinds: [...GROUND_GRIND_VALUES], image: "/assets/cafe-precision-500-front.jpg" },
    ],
  },
  {
    id: "honey",
    slug: "microlote-honey",
    category: "honey",
    name: "Microlote Honey",
    subtitle: "Una edición para descubrir",
    description: "Una expresión pequeña de la finca: cuerpo medio-alto, acidez media y una taza para tomar sin afán.",
    process: "Honey · microlote",
    origin: "Finca La Libertad · Cachipay",
    altitude: "Altura por confirmar",
    notes: ["Cuerpo medio-alto", "Acidez media", "Lote pequeño"],
    badge: "Edición limitada",
    image: "/assets/cafe-honey-beans-closeup.jpg",
    published: true,
    variants: [
      { id: "honey-340", label: "340 g · referencia", weightGrams: 340, priceCop: 35000, priceConfirmed: false, stock: 0, grinds: [...GROUND_GRIND_VALUES], image: "/assets/cafe-honey-beans-closeup.jpg" },
    ],
  },
];

export async function getCatalog(): Promise<Product[]> {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) return previewCatalog;

  try {
    const supabase = createClient(url, key, { auth: { persistSession: false } });
    const { data, error } = await supabase
      .from("storefront_catalog")
      .select("product_id, slug, category, name, subtitle, description, process, origin, altitude, notes, badge, image_url, sort_order, variant_id, variant_label, weight_grams, price_cop, price_confirmed, available_stock, grinds, variant_image_url, variant_sort_order")
      .order("sort_order", { ascending: true }).order("variant_sort_order", { ascending: true });
    if (error || !data?.length) return [];

    const products = new Map<string, Product>();
    for (const row of data as any[]) {
      let product = products.get(row.product_id);
      if (!product) {
        product = {
          id: row.product_id, slug: row.slug, category: row.category, name: row.name,
          subtitle: row.subtitle, description: row.description, process: row.process,
          origin: row.origin, altitude: row.altitude, notes: row.notes ?? [], badge: row.badge,
          image: row.image_url, variants: [], published: true,
        };
        products.set(product.id, product);
      }
      product.variants.push({
        id: row.variant_id, label: row.variant_label, weightGrams: row.weight_grams,
        priceCop: row.price_cop ?? 0, priceConfirmed: row.price_confirmed,
        stock: row.available_stock ?? 0, grinds: row.grinds ?? ["Molido"], image: row.variant_image_url ?? row.image_url,
      });
    }
    return [...products.values()];
  } catch {
    // A live catalog failure must not silently show stale reference prices as current stock.
    return [];
  }
}

export function formatCOP(value: number) {
  return new Intl.NumberFormat("es-CO", { style: "currency", currency: "COP", maximumFractionDigits: 0 }).format(value);
}
