import "server-only";
import { hasDatabaseConfig } from "@/lib/supabase/admin";

export function isStoreCheckoutEnabled() {
  const mode = process.env.WOMPI_ENVIRONMENT;
  const publicKey = process.env.WOMPI_PUBLIC_KEY ?? "";
  const privateKey = process.env.WOMPI_PRIVATE_KEY ?? "";
  const keyMatchesEnvironment =
    mode === "test"
      ? publicKey.startsWith("pub_test_") && privateKey.startsWith("prv_test_")
      : mode === "production"
        ? publicKey.startsWith("pub_prod_") &&
          privateKey.startsWith("prv_prod_")
        : false;
  const policyVersion = process.env.PRIVACY_POLICY_VERSION?.trim() ?? "";
  const policyReady =
    policyVersion.length > 0 &&
    policyVersion.length <= 80 &&
    !/draft/i.test(policyVersion);

  let siteUrl: URL;
  try {
    siteUrl = new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "");
  } catch {
    return false;
  }

  const secureProtocol =
    siteUrl.protocol === "https:" ||
    (process.env.NODE_ENV !== "production" &&
      siteUrl.protocol === "http:" &&
      ["localhost", "127.0.0.1"].includes(siteUrl.hostname));
  const validSiteUrl =
    !siteUrl.username &&
    !siteUrl.password &&
    !siteUrl.search &&
    !siteUrl.hash &&
    siteUrl.pathname === "/" &&
    secureProtocol;

  return (
    process.env.STORE_CHECKOUT_ENABLED === "true" &&
    policyReady &&
    validSiteUrl &&
    hasDatabaseConfig() &&
    Boolean(process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY) &&
    keyMatchesEnvironment &&
    Boolean(
      process.env.WOMPI_INTEGRITY_SECRET && process.env.WOMPI_EVENTS_SECRET,
    )
  );
}
