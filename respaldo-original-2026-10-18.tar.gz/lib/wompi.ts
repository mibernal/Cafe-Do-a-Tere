import "server-only";
import { createHash, timingSafeEqual } from "node:crypto";
import { z } from "zod";

const authoritativeTransactionSchema = z
  .object({
    data: z
      .object({
        id: z.string().min(1).max(120),
        reference: z.string().min(1).max(255),
        status: z.enum(["PENDING", "APPROVED", "DECLINED", "ERROR", "VOIDED"]),
        amount_in_cents: z.number().int().positive().safe(),
        currency: z.literal("COP"),
      })
      .passthrough(),
  })
  .passthrough();

export function wompiCheckoutConfig(
  reference: string,
  amountCop: number,
  trackingToken: string,
) {
  const publicKey = process.env.WOMPI_PUBLIC_KEY;
  const secret = process.env.WOMPI_INTEGRITY_SECRET;
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL;
  if (!publicKey || !secret || !siteUrl)
    throw new Error("Wompi is not configured.");
  const amountInCents = Math.round(amountCop * 100);
  const expirationTime = new Date(Date.now() + 30 * 60 * 1000).toISOString();
  const integrity = createHash("sha256")
    .update(`${reference}${amountInCents}COP${expirationTime}${secret}`)
    .digest("hex");
  return {
    action: "https://checkout.wompi.co/p/",
    publicKey,
    currency: "COP",
    amountInCents,
    reference,
    integrity,
    expirationTime,
    redirectUrl: `${siteUrl.replace(/\/$/, "")}/seguimiento/${encodeURIComponent(trackingToken)}`,
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function readPath(source: unknown, dottedPath: string): unknown {
  return dottedPath.split(".").reduce<unknown>((value, key) => {
    if (!isRecord(value)) return undefined;
    return value[key];
  }, source);
}

export function verifyWompiEvent(
  event: unknown,
  headerChecksum: string | null,
  requiredProperties: string[] = [],
) {
  const secret = process.env.WOMPI_EVENTS_SECRET;
  if (
    !secret ||
    !isRecord(event) ||
    !isRecord(event.signature) ||
    !isRecord(event.data)
  )
    return false;
  const configuredEnvironment = process.env.WOMPI_ENVIRONMENT;
  const expectedEnvironment =
    configuredEnvironment === "production"
      ? "prod"
      : configuredEnvironment === "test"
        ? "test"
        : null;
  if (!expectedEnvironment || event.environment !== expectedEnvironment)
    return false;

  const timestamp = event.timestamp;
  const properties = event.signature.properties;
  if (
    !Number.isSafeInteger(timestamp) ||
    (timestamp as number) < 0 ||
    !Array.isArray(properties) ||
    properties.length < 1 ||
    properties.length > 30
  )
    return false;
  if (requiredProperties.some((property) => !properties.includes(property)))
    return false;
  if (
    Math.abs(Math.floor(Date.now() / 1000) - (timestamp as number)) >
    48 * 60 * 60
  )
    return false;
  if (
    !properties.every(
      (path) =>
        typeof path === "string" &&
        path.length <= 160 &&
        /^[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*$/.test(path) &&
        !/(?:^|\.)(?:__proto__|prototype|constructor)(?:\.|$)/.test(path),
    )
  )
    return false;

  const bodyChecksum =
    typeof event.signature.checksum === "string"
      ? event.signature.checksum.toLowerCase()
      : "";
  const headerValue = headerChecksum?.toLowerCase() ?? "";
  if (bodyChecksum && headerValue && bodyChecksum !== headerValue) return false;
  const checksum = bodyChecksum || headerValue;
  if (!/^[a-f0-9]{64}$/.test(checksum)) return false;

  const parts = properties.map((path) => readPath(event.data, path as string));
  if (
    parts.some(
      (part) =>
        !["string", "number", "boolean"].includes(typeof part) ||
        !Number.isFinite(typeof part === "number" ? part : 0),
    )
  )
    return false;
  // Wompi signs the configured data properties and timestamp, not a re-serialized JSON body.
  const expected = createHash("sha256")
    .update(`${parts.join("")}${timestamp}${secret}`)
    .digest("hex");
  const expectedBytes = Buffer.from(expected);
  const checksumBytes = Buffer.from(checksum);
  return (
    expectedBytes.length === checksumBytes.length &&
    timingSafeEqual(expectedBytes, checksumBytes)
  );
}

export async function fetchWompiTransaction(transactionId: string) {
  const environment = process.env.WOMPI_ENVIRONMENT;
  const privateKey = process.env.WOMPI_PRIVATE_KEY ?? "";
  const isTest = environment === "test" && privateKey.startsWith("prv_test_");
  const isProduction =
    environment === "production" && privateKey.startsWith("prv_prod_");
  if (!isTest && !isProduction)
    throw new Error(
      "Wompi private key is not configured for the selected environment.",
    );

  const baseUrl = isTest
    ? "https://sandbox.wompi.co/v1"
    : "https://production.wompi.co/v1";
  const response = await fetch(
    `${baseUrl}/transactions/${encodeURIComponent(transactionId)}`,
    {
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${privateKey}`,
      },
      cache: "no-store",
      signal: AbortSignal.timeout(10_000),
    },
  );
  if (!response.ok)
    throw new Error(
      `Wompi transaction lookup failed with status ${response.status}.`,
    );
  const parsed = authoritativeTransactionSchema.safeParse(
    await response.json(),
  );
  if (!parsed.success)
    throw new Error("Wompi returned an invalid transaction response.");
  return parsed.data.data;
}
