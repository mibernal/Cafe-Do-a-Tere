export type ProductVariant = {
  id: string;
  label: string;
  weightGrams: number;
  priceCop: number;
  priceConfirmed: boolean;
  stock: number;
  grinds: string[];
  image: string;
};

export type Product = {
  id: string;
  slug: string;
  category: "wood" | "precision" | "honey" | "gift";
  name: string;
  subtitle: string;
  description: string;
  process: string;
  origin: string;
  altitude: string;
  notes: string[];
  badge: string;
  image: string;
  variants: ProductVariant[];
  published: boolean;
};
